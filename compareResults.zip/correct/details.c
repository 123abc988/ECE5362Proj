  Hex/Decimal memory dump (least significant word on left)
  Only lines with at least one nonzero value printed
     0/   0. : (  240/   576.)( FFFE/    -2.)(  301/   769.)(    0/     0.)
     4/   4. : (    1/     1.)(    2/     2.)(    3/     3.)(    4/     4.)
     8/   8. : (    5/     5.)(    0/     0.)(    0/     0.)(    0/     0.)
 state is decimal format; registers are hex 

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   starting instruction 1
    0    7    5   8   0    0    0    0    0    0    0   0    0    0 0000 [pc] -> mar     
    1    7    5   8   0    0    0    0    0    0    0   0    0    0 0000 [[mar]] -> mdr  
    2    7    5   8   0    0    0    0    0    0    0   0  240    0 0000 [mdr] -> ir     
    3    7    5   8   0    0    0    0    0    0    0   0  240  240 0000 [pc]+1 -> q     
    4    7    5   8   0    0    1    0    0    0    0   0  240  240 0000 [q] -> pc       

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   22    7    5   8   1    0    1    0    0    0    0   0  240  240 0000 --              
   23    7    5   8   1    0    1    0    0    0    0   0  240  240 0000 [pc] -> mar     
   24    7    5   8   1    0    1    0    0    0    0   1  240  240 0000 [[mar]] -> mdr  
   25    7    5   8   1    0    1    0    0    0    0   1 FFFE  240 0000 [pc] + 1 -> q   
   26    7    5   8   1    0    2    0    0    0    0   1 FFFE  240 0000 [q] -> pc       

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   27    7    5   8   2    0    2    0    0    0    0   1 FFFE  240 0000 --              
   35    7    5   8   2    0    2    0    0    0    0   1 FFFE  240 0000 [mdr] -> t1     
   36    7    5   8   2 FFFE    2    0    0    0    0   1 FFFE  240 0000 [t1] + [r] -> q 
   37    7    5   8   2 FFFE    5    0    0    0    0   1 FFFE  240 0000 [q] -> mar&t5   
   33    7    5   8   2 FFFE    5    0    0    0    5   5 FFFE  240 0000 [[mar]] -> mdr  

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   34    7    5   8   2 FFFE    5    0    0    0    5   5    2  240 0000 [mdr] -> t4     
   39    7    5   8   2 FFFE    5    0    0    2    5   5    2  240 0000 --              
   40    7    5   8   2 FFFE    5    0    0    2    5   5    2  240 0000 --              
   70    7    5   8   2 FFFE    5    0    0    2    5   5    2  240 0000 [t4]+1->q       
   71    7    5   8   2 FFFE    3    0    0    2    5   5    2  240 0000 [q] -> mdr      

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   72    7    5   8   2 FFFE    3    0    0    2    5   5    3  240 0000 [t5] -> mar     
   73    7    5   8   2 FFFE    3    0    0    2    5   5    3  240 0000 [mdr] -> [mar]  
   starting instruction 2
    0    7    5   8   2 FFFE    3    0    0    2    5   5    3  240 0000 [pc] -> mar     
    1    7    5   8   2 FFFE    3    0    0    2    5   2    3  240 0000 [[mar]] -> mdr  
    2    7    5   8   2 FFFE    3    0    0    2    5   2  301  240 0000 [mdr] -> ir     

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
    3    7    5   8   2 FFFE    3    0    0    2    5   2  301  301 0000 [pc]+1 -> q     
    4    7    5   8   2 FFFE    3    0    0    2    5   2  301  301 0000 [q] -> pc       
   22    7    5   8   3 FFFE    3    0    0    2    5   2  301  301 0000 --              
   28    7    5   8   3 FFFE    3    0    0    2    5   2  301  301 0000 [r] -> t4       
   39    7    5   8   3 FFFE    3    0    0    5    5   2  301  301 0000 --              

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   40    7    5   8   3 FFFE    3    0    0    5    5   2  301  301 0000 --              
   77    7    5   8   3 FFFE    3    0    0    5    5   2  301  301 0000 [t4] -> t1      
   78    7    5   8   3    5    3    0    0    5    5   2  301  301 0000 [t1] - 1 -> q   
   84    7    5   8   3    5    4    0    0    5    5   2  301  301 1000 [q] -> r        
   starting instruction 3
    0    7    4   8   3    5    4    0    0    5    5   2  301  301 1000 [pc] -> mar     

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
    1    7    4   8   3    5    4    0    0    5    5   3  301  301 1000 [[mar]] -> mdr  
    2    7    4   8   3    5    4    0    0    5    5   3    0  301 1000 [mdr] -> ir     
    3    7    4   8   3    5    4    0    0    5    5   3    0    0 1000 [pc]+1 -> q     
    4    7    4   8   3    5    4    0    0    5    5   3    0    0 1000 [q] -> pc       
   41    7    4   8   4    5    4    0    0    5    5   3    0    0 1000 --              
  test c: Halt instruction executed 
  Hex/Decimal memory dump (least significant word on left)
  Only lines with at least one nonzero value printed
     0/   0. : (  240/   576.)( FFFE/    -2.)(  301/   769.)(    0/     0.)
     4/   4. : (    1/     1.)(    3/     3.)(    3/     3.)(    4/     4.)
     8/   8. : (    5/     5.)(    0/     0.)(    0/     0.)(    0/     0.)
