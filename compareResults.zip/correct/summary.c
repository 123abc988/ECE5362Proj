 memory write::    3->M(   5)
  At end of instruction 1
    ac    x   sp   pc   t1    q   t2   t3   t4   t5  mar  mdr   ir cvzn
     7    5    8    2 FFFE    3    0    0    2    5    5    3  240 0000 
  At end of instruction 2
    ac    x   sp   pc   t1    q   t2   t3   t4   t5  mar  mdr   ir cvzn
     7    4    8    3    5    4    0    0    5    5    2  301  301 1000 
