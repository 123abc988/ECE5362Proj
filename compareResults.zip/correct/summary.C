 memory write:: FFFF->M(   1)
  At end of instruction 1
    ac    x   sp   pc   t1    q   t2   t3   t4   t5  mar  mdr   ir cvzn
     4    5    6    2    0 FFFF    0    0    1    1    1 FFFF  450 0001 
