  Hex/Decimal memory dump (least significant word on left)
  Only lines with at least one nonzero value printed
     0/   0. : (  450/  1104.)(    1/     1.)(    0/     0.)(    0/     0.)
     4/   4. : (    1/     1.)(    2/     2.)(    3/     3.)(    4/     4.)
     8/   8. : (    5/     5.)(    0/     0.)(    0/     0.)(    0/     0.)
 state is decimal format; registers are hex 
   starting instruction 1
    0    4    5   6   0    0    0    0    0    0    0   0    0    0 0000 [pc] -> mar     
    1    4    5   6   0    0    0    0    0    0    0   0    0    0 0000 [[mar]] -> mdr  

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
    2    4    5   6   0    0    0    0    0    0    0   0  450    0 0000 [mdr] -> ir     
    3    4    5   6   0    0    0    0    0    0    0   0  450  450 0000 [pc]+1 -> q     
    4    4    5   6   0    0    1    0    0    0    0   0  450  450 0000 [q] -> pc       
   22    4    5   6   1    0    1    0    0    0    0   0  450  450 0000 --              
   23    4    5   6   1    0    1    0    0    0    0   0  450  450 0000 [pc] -> mar     

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   24    4    5   6   1    0    1    0    0    0    0   1  450  450 0000 [[mar]] -> mdr  
   25    4    5   6   1    0    1    0    0    0    0   1    1  450 0000 [pc] + 1 -> q   
   26    4    5   6   1    0    2    0    0    0    0   1    1  450 0000 [q] -> pc       
   27    4    5   6   2    0    2    0    0    0    0   1    1  450 0000 --              
   38    4    5   6   2    0    2    0    0    0    0   1    1  450 0000 [mdr] -> mar&t5 

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   33    4    5   6   2    0    2    0    0    0    1   1    1  450 0000 [[mar]] -> mdr  
   34    4    5   6   2    0    2    0    0    0    1   1    1  450 0000 [mdr] -> t4     
   39    4    5   6   2    0    2    0    0    1    1   1    1  450 0000 --              
   40    4    5   6   2    0    2    0    0    1    1   1    1  450 0000 --              
   85    4    5   6   2    0    2    0    0    1    1   1    1  450 0000 0-[t4] -> q     

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   86    4    5   6   2    0 FFFF    0    0    1    1   1    1  450 0000 [q] -> mdr      
   87    4    5   6   2    0 FFFF    0    0    1    1   1 FFFF  450 0001 [t5] -> mar     
   88    4    5   6   2    0 FFFF    0    0    1    1   1 FFFF  450 0001 [mdr] -> [mar]  
   starting instruction 2
    0    4    5   6   2    0 FFFF    0    0    1    1   1 FFFF  450 0001 [pc] -> mar     
    1    4    5   6   2    0 FFFF    0    0    1    1   2 FFFF  450 0001 [[mar]] -> mdr  

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
    2    4    5   6   2    0 FFFF    0    0    1    1   2    0  450 0001 [mdr] -> ir     
    3    4    5   6   2    0 FFFF    0    0    1    1   2    0    0 0001 [pc]+1 -> q     
    4    4    5   6   2    0    3    0    0    1    1   2    0    0 0001 [q] -> pc       
   41    4    5   6   3    0    3    0    0    1    1   2    0    0 0001 --              
  test C: Halt instruction executed 
  Hex/Decimal memory dump (least significant word on left)
  Only lines with at least one nonzero value printed
     0/   0. : (  450/  1104.)( FFFF/    -1.)(    0/     0.)(    0/     0.)
     4/   4. : (    1/     1.)(    2/     2.)(    3/     3.)(    4/     4.)
     8/   8. : (    5/     5.)(    0/     0.)(    0/     0.)(    0/     0.)
