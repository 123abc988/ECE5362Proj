  Hex/Decimal memory dump (least significant word on left)
  Only lines with at least one nonzero value printed
     0/   0. : (    0/     0.)( 3600/ 13824.)(    0/     0.)(    0/     0.)
     4/   4. : (    1/     1.)(    2/     2.)(    3/     3.)(    4/     4.)
     8/   8. : (    5/     5.)(    0/     0.)(    0/     0.)(    0/     0.)
 state is decimal format; registers are hex 

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   starting instruction 1
    0    4    5   6   1    0    0    0    0    0    0   0    0    0 0000 [pc] -> mar     
    1    4    5   6   1    0    0    0    0    0    0   1    0    0 0000 [[mar]] -> mdr  
    2    4    5   6   1    0    0    0    0    0    0   1 3600    0 0000 [mdr] -> ir     
    3    4    5   6   1    0    0    0    0    0    0   1 3600 3600 0000 [pc]+1 -> q     
    4    4    5   6   1    0    2    0    0    0    0   1 3600 3600 0000 [q] -> pc       

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
    5    4    5   6   2    0    2    0    0    0    0   1 3600 3600 0000 --              
    6    4    5   6   2    0    2    0    0    0    0   1 3600 3600 0000 [pc] -> mar     
    7    4    5   6   2    0    2    0    0    0    0   2 3600 3600 0000 [[mar]] -> mdr  
    8    4    5   6   2    0    2    0    0    0    0   2    0 3600 0000 [pc] + 1 -> q   
    9    4    5   6   2    0    3    0    0    0    0   2    0 3600 0000 [q] -> pc       

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
   21    4    5   6   3    0    3    0    0    0    0   2    0 3600 0000 [mdr] -> t2     
   22    4    5   6   3    0    3    0    0    0    0   2    0 3600 0000 --              
   28    4    5   6   3    0    3    0    0    0    0   2    0 3600 0000 [r] -> t4       
   39    4    5   6   3    0    3    0    0    4    0   2    0 3600 0000 --              
  122    4    5   6   3    0    3    0    0    4    0   2    0 3600 0000 --              

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
  131    4    5   6   3    0    3    0    0    4    0   2    0 3600 0000 [t2] -> r       
   starting instruction 2
    0    0    5   6   3    0    3    0    0    4    0   2    0 3600 0010 [pc] -> mar     
    1    0    5   6   3    0    3    0    0    4    0   3    0 3600 0010 [[mar]] -> mdr  
    2    0    5   6   3    0    3    0    0    4    0   3    0 3600 0010 [mdr] -> ir     
    3    0    5   6   3    0    3    0    0    4    0   3    0    0 0010 [pc]+1 -> q     

   st   ac    x  sp  pc   t1    q   t2   t3   t4   t5 mar  mdr   ir cvzn reg xfer
    4    0    5   6   3    0    4    0    0    4    0   3    0    0 0010 [q] -> pc       
   41    0    5   6   4    0    4    0    0    4    0   3    0    0 0010 --              
  test R: Halt instruction executed 
  Hex/Decimal memory dump (least significant word on left)
  Only lines with at least one nonzero value printed
     0/   0. : (    0/     0.)( 3600/ 13824.)(    0/     0.)(    0/     0.)
     4/   4. : (    1/     1.)(    2/     2.)(    3/     3.)(    4/     4.)
     8/   8. : (    5/     5.)(    0/     0.)(    0/     0.)(    0/     0.)
