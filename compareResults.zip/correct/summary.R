  At end of instruction 1
    ac    x   sp   pc   t1    q   t2   t3   t4   t5  mar  mdr   ir cvzn
     0    5    6    3    0    3    0    0    4    0    2    0 3600 0010 
